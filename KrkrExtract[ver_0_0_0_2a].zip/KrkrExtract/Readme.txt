﻿KrkrExtract[Ver 0.0.0.2a]

Author:X'moe
目前提供krkr2和krkrz（包括M2公司）通用提取

使用方式：将原始游戏exe（或者破解后能运行的exe）拖进KrkrExtract.exe进行加载
在这之前请关闭杀软之类的软件（特别是大数字）
如果成功后，会自动生成一个窗口，你现在可以把xp3文件拖进来进行拆包。
（最好是等游戏停留在title处开始拆包）
！！！！！但是请记得，要拆第二个包的时候一定要关一次游戏！！！！
（后期版本我会改进的，主要是自己太懒）

拆包后的文件在outPath里面。

Support:
xmoe.project@gmail.com

[Dev log]

Version 0.0.0.2a:
修正提取bug，支持未知Chunk的分析。
改进提取线程。
内置IA32反编译器引擎，用于分析加密流程（目前暂时没开放这个功能）
内置LE Mudole，如果你系统默认的CodePage不是日区的，在提取某些krkrz开发的游戏时，
部分提取可能会失败。KrkrExtract会自动启动LE Module。

给KrkrExtract.exe增加功能：
在无额外参数启动的情况下（就是直接双击KrkrExtract.exe），会启动资源提取器。
Krkr相关的（如*.psb *.scn *.tlg *.pimg）资源可以进行提取。
目前支持TLG5/6的提取
*.PSB *.SCN 二进制脚本的反编译

=========================================

Version 0.0.1.a:
添加进度。
在提取多个文件的时候，不必重启游戏（但是不能同时提取多个文件，请依次拖放）

Todo：
M2公司某些xp3压缩包中的某些文件可能会提取失败，正在找解决办法。


Test Release:

Todo：
目前不支持Loader的加载（详见注释1）
目前不支持一键封包（懒）


注释：
①有的游戏包括原版游戏是用Loader机制加载的，特别是汉化版游戏，
目前暂时不支持这种游戏的拆包（虽然要支持也很简单）