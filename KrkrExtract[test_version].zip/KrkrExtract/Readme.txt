﻿KrkrExtract[Test Version]

Author:X'moe
目前提供krkr2和krkrz（包括M2公司）通用提取

使用方式：将原始游戏exe（或者破解后能运行的exe）拖进KrkrExtract.exe进行加载
在这之前请关闭杀软之类的软件（特别是大数字）
如果成功后，会自动生成一个窗口，你现在可以把xp3文件拖进来进行拆包。
（最好是等游戏停留在title处开始拆包）
！！！！！但是请记得，要拆第二个包的时候一定要关一次游戏！！！！
（后期版本我会改进的，主要是自己太懒）

拆包后的文件在outPath里面。

Todo：
目前不支持Loader的加载（详见注释1）
目前不支持一键封包（懒）

Support:
xmoe.project@gmail.com

注释：
①有的游戏包括原版游戏是用Loader机制加载的，特别是汉化版游戏，
目前暂时不支持这种游戏的拆包（虽然要支持也很简单）